#include <stdio.h>
#include <math.h>

void fibonacci(int n){
    int n1 = 0; 
    int n2 = 1; 
    printf("%d\n", n1);
    printf("%d\n", n2);
    for (int i = 2; i < n; i = i + 1){
        // your code here
    }
}

void main(){
    fibonacci(10);
}