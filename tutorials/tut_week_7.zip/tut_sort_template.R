# swap two elements in an vector 
swap <- function(v, i, j){
  
  # YOUR CODE HERE
  
}

# find the index of the largest element in an vector
find_max_idx <- function(v){
  
  # YOUR CODE HERE
  
}


# sort an vector
sort <- function(v){
  
  # YOUR CODE HERE
  
}

# recursive version
sort_v2 <- function(v){
  
  # YOUR CODE HERE
  
}

# selection sort: recursive version
sort_sel_rec <- function(v){
  
  # YOUR CODE HERE
  
}

# selection sort: loop version
sort_sel_loop <- function(v){
  
  # YOUR CODE HERE
  
}

v <- c(5,3,2,4)
len <- 4

print("testing find_max_idx-----------------------")
# testing find_min_idx
min_idx <- find_max_idx(v)
cat(sprintf("max_idx: %d\n", min_idx))

cat("testing swap-----------------------\n")
#testing swap
# YOUR CODE HERE

cat("testing sort-----------------------\n")
#test sort
a <- c(5, 3, 2, 1, 2, 4)
# YOUR CODE HERE

b <- c(5, 3, 2, 1, 2, 4)
print("testing sort (recursive)-----------------------")
# YOUR CODE HERE

c <- c(5, 3, 2, 1, 2, 4)
print("testing selection sort (loop)-----------------------")
# YOUR CODE HERE

d <- c(5, 3, 2, 1, 2, 4)
print("testing selection sort (recursive)-----------------------")
# YOUR CODE HERE

print("Following the lecture, sort and sort_v2 will take")
# YOUR CODE HERE
