#include <stdio.h>

void main(){
    // write code below. 
}