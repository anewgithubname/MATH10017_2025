#include <stdio.h>

// write the max function below. Think: 
// 1. what is the return type of the function? 
// 2. What are the input variables of the function? what are the types of those? 
// 3. How to write the function itself? 


void main(){
    // change the line below with different values of a, b and c
    // to test your program. 
    int a = 5, b = 2, c = 0;
    printf("the maximum among %d, %d, %d is %d \n", a, b, c, max(a,b,c));
}