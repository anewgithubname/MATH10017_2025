#include <stdio.h>

/* write a function named "is_divisible" below
input: an integer variable named num
output: none
*/

void main(){
    int num = 9*4*3+1; 

    //modulo operator is %

    //call is_divisible function in a loop, 
    //so that it checks the divisibility for all integers from 939 to 945
    // Hint, I? C? D? U?

}