#include <stdio.h>

void main(){

    int i;
    for(i=1; i<=10; i = i + 1){
        printf("%d\n", i);
    }

    printf("the end\n");
}