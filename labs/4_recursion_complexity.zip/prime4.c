#include <stdio.h>

// write num_factors function below. 
// two inputs, i > j > 1
// one integer output. 

void main()
{
    // test your num_factors below with different i, j
    // for example, 
    // printf("%d\n", num_factors(16, 5));
}