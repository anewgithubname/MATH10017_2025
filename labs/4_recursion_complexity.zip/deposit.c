# include <stdio.h>

/*
new balance = balane + balance * 0.05

For year y > 0
balance(y) = balance(y-1) * 1.05

balance(0) = 1000

*/

double balance_rec(int year){
    if (year == 0){
        return 1000;
    }else{
        return balance_rec(year - 1) * 1.05;
    }
}

int main(){
    double balance = 1000.0;

    /*
    formula: 
    (1.05^10) * 1000
    or 
    1.05 * 1.05 ... * 1.05 * 1000
    */

    double s = 1.05;
    for (int i =1; i <= 9; i = i + 1){
        s = s * 1.05; 
    }

    balance = balance * s; 

    printf("new balane: %.5f\n", balance);


    double balance2 = balance_rec(10);
    printf("new balance: %.5f", balance2);

}