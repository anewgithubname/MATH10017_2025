# include <stdio.h>

/*
new balance = balane + interest

For year y > 0
balance(y) = balance(y-1) + interest

balance(0) = 1000

*/

double balance(int year){
    // write your code here:
}

int main(){
    printf("%d\n", balance(10));
}