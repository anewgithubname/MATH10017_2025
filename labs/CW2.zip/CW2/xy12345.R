## TEMPLATE SOLUTION FILE

rm(list = ls())
# Load the data, make sure that you are in the right folder
load(file = "CW2_25.RData")
uob_email <- "xy12345@bristol.ac.uk" # TODO: change this to your Bristol email
my_seed <- as.numeric(gsub("\\D", "", uob_email))
print(my_seed)
set.seed(my_seed)
A_test <- matrix(sample(1:9), 3, 3)
V_test <- matrix(sample(1:12), 4, 3)
W_test <- matrix(sample(1:8), 4, 2)
H_test <- matrix(sample(1:6), 2, 3)
my_seed_2 <- sample(c(1, 3, 4, 5, 6))[1]
set.seed(my_seed_2)
print(my_seed_2)
V <- V[sample(nrow(V)), ]

# YOU CODE HERE