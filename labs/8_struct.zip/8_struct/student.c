#include <stdio.h>
struct student{
    int ID;
    char *name;
    int grade;
}; //Define a structure before you use it!! 

//TODO: define a function that takes a student struct and prints out the student's info

void main(){
    struct student song; //declare a student variable
    //initialize
    song.ID = 1024; 
    song.name = "song liu";
    song.grade = 70; 

    printf("%s\n", song.name); //displays "song liu"
    
    //declare + initialize in one line. 
    struct student jack = {1234, "jack", 71};

    printf("%s\n", jack.name); //displays "jack"


    //TODO: test your print function here. 
    
}