#include <stdio.h>
void main(){
    int a[] = {2,3,4}; int *pa = &a[0];

    printf("%d\n", pa[2]);
    //prints out, 4

    // TODO: write a for loop, printing out contents in a, using the array indexing notation a[i]. 

    // TODO: write a for loop, printing out contents in a, WITHOUT using the array indexing notation a[i]. 
}