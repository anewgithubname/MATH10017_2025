#include <stdio.h>

void swap(int *pa, int *pb){
    // function body. 
    // your code here. 
}

void main(){
    int a1 = 3, a2 = 2; 

    //call your function here
    //you should not swap values of a1 and a2 in the main function. 
    //you must call a function to swap values for you.

    printf("%d %d\n", a1, a2); 
    // should display "2 3"
}