#include <stdio.h>

void main(){
    int a[] = {2,3,4}; int *pa = &a[0];

    printf("%p\n", pa); // the pointer points to the first element
    printf("%p\n", pa+1); // the pointer + 1

    printf("\n");

    printf("%p\n", &a[0]); // the address of the first element
    printf("%p\n", &a[1]); // the address of the 2nd element

    printf("\n");

    printf("a[1] is %d\n", a[1]); // prints out a[1]
    printf("pa[1] is %d\n", pa[1]); // prints out pa[1], the same as a[1] 
    // You can use pa and a interchangeably!!
}